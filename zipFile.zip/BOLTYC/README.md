# gestoracademicoyc-02-08-2026

[![Open in Bolt](https://bolt.new/static/open-in-bolt.svg)](https://bolt.new/~/sb1-2p7axwng)
